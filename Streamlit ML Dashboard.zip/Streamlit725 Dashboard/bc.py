import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import seaborn as sns; sns.set(style="ticks", color_codes=True)
import pickle
from matplotlib import pyplot as plt
from collections import Counter
from sklearn.metrics import classification_report
from sklearn.metrics import roc_curve, auc
import xgboost as xgb
import joblib
from sklearn.feature_selection import RFECV
import matplotlib.colors as colors
from sklearn.metrics import accuracy_score, confusion_matrix
# from scipy import stats
from sklearn.preprocessing import LabelEncoder, StandardScaler
# from scipy.stats import skew
import seaborn as sns; sns.set(style="ticks", color_codes=True)
from sklearn.model_selection import train_test_split, StratifiedKFold, GridSearchCV, cross_val_score
from sklearn.linear_model import LogisticRegression # to apply the Logistic regression
from sklearn.model_selection import train_test_split # to split the data into two parts
from sklearn.model_selection import GridSearchCV# for tuning parameter
from sklearn.ensemble import RandomForestClassifier # for random forest classifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn import svm # for Support Vector Machine
from sklearn import metrics # for the check the error and accuracy of the model
# import os
# import random
import csv
import streamlit as st
import pytz
from PIL import Image
st.set_option('deprecation.showPyplotGlobalUse', False)

# import warnings
import warnings
# filter warnings
warnings.filterwarnings('ignore')



image = Image.open('Breast cancer logo.jpg')

st.image(image, caption=None, width=200, use_column_width=150)

st.write("<span style='color:red'>Slight Delays may be experienced as Results, Graphs & Images are generated "
         "real time from codes</span>", unsafe_allow_html=True)

# Map function names to ticker symbols
function_map = {
    "Data Explorations": "Data Explorations",
    "Data Visualizations Group 1": "Data Visualizations Group 1",
    "Data Visualizations Group 2": "Data Visualizations Group 2",
    "Data Visualizations Group 3": "Data Visualizations Group 3",
    "Models Performances Result 1": "Models Performances Result 1",
    "Models Performances Result 2": "Models Performances Result 2",
    "Models Performances Result 3": "Models Performances Result 3",
    "Predicting Cancer Types": "Predicting Cancer Types",
}

# Extracting real-time data for the selected function
function = st.sidebar.selectbox("Select function", ("Data Explorations", "Data Visualizations Group 1", "Data Visualizations Group 2",
                                                    "Data Visualizations Group 3", "Models Performances Result 1",
                                                    "Models Performances Result 2", "Models Performances Result 3",
                                                    "Predicting Cancer Types"))
ticker = function_map[function]

# Read in the breast cancer data
data = pd.read_csv('breast-cancer-wisconsin-data.csv')

# Display the selected function name next to the subheader
st.subheader(f"Breast Cancer Dashboard - {function}")

# Drop the ID column
data.drop(columns=['id'], inplace=True)

# Calculate basic statistics for each column in the data set
if function == "Data Explorations":
    st.write("Basic statistics description:")
    st.write(data.describe())
    st.write("Comparing means of benign & malignant cancer :")
    st.write(data.groupby('diagnosis').mean())
    st.write("Diagnosis value count:")
    st.write(data.diagnosis.value_counts())


# Visualizing Data Group 1
if function == "Data Visualizations Group 1":
    st.write("Visualizing the diagnosis barchart value count :")
    colors = ["green", "red"]
    sns.barplot(x=data.diagnosis.value_counts().index, y=data.diagnosis.value_counts(), palette=colors)
    plt.xlabel("Type of cancer cell")
    plt.ylabel("Count")
    plt.title("Counts of B and M Cancer Cell")
    st.pyplot()

    st.write("Visualizing the diagnosis piechart value count :")
    labels = data.diagnosis.value_counts().index
    colors = ['green', 'red']
    explode = [0, 0]
    sizes = [357, 212]
    plt.figure(figsize=(6, 6))
    plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct='%1.1f%%')
    # plt.title('Percentage of Diagnosis Cancers', color='blue', fontsize=15)
    st.pyplot()

    st.write("Visualize the distribution of data set using histograms :")
    data.hist(bins=50, figsize=(20, 15))
    st.pyplot()

    st.write("Distribution plots to visualize skewness")
    y = data.diagnosis
    x = data.drop(columns="diagnosis")

    fig, axes = plt.subplots(nrows=3, ncols=5, figsize=(12, 8))

    for i, ax in enumerate(axes.flatten()):
        g = sns.distplot(x.iloc[:, i], color="b", label="Skewness : %.2f" % (x.iloc[:, i].skew()), ax=ax)
        g = g.legend(loc="best")

    plt.tight_layout()
    st.pyplot()

# Visualizing Data Group 2
if function == "Data Visualizations Group 2":
    st.write("Visualizing the box plot of se data set :")
    y = data.diagnosis
    x = data.drop(columns="diagnosis")

    # As we can see, our dataset has 3 categoriel features. We have mean, se and worst categories. So we will divide 3 categories all of features.
    # The mean, standard error and "worst" or largest (mean of the three largest values) of these features were computed for each image,
    # resulting in 30 features. For instance, field 3 is Mean Radius, field 13 is Radius SE, field 23 is Worst Radius.

    mean_data = ['radius_mean', 'texture_mean', 'perimeter_mean', 'area_mean', 'smoothness_mean', 'compactness_mean',
                 'concavity_mean', 'concave points_mean', 'symmetry_mean', 'fractal_dimension_mean']
    se_data = ['radius_se', 'texture_se', 'perimeter_se', 'area_se', 'smoothness_se', 'compactness_se', 'concavity_se',
               'concave points_se', 'symmetry_se', 'fractal_dimension_se']
    worst_data = ['radius_worst', 'texture_worst', 'perimeter_worst', 'area_worst', 'smoothness_worst',
                  'compactness_worst', 'concavity_worst', 'concave points_worst', 'symmetry_worst',
                  'fractal_dimension_worst']

    # After categorising, we will add our target values(diagnosis/ y) in 3 equals
    x_ = (x - x.mean()) / x.std()  # standardization to group all similar (se, mean and worst features together)

    colors = ["red", "green"]
    mean_breast_cancer = pd.concat([y, x_.iloc[:, 0:10]], axis=1)
    mean_breast_cancer = pd.melt(mean_breast_cancer, id_vars="diagnosis", var_name="features", value_name='value')

    se_breast_cancer = pd.concat([y, x_.iloc[:, 10:20]], axis=1)
    se_breast_cancer = pd.melt(se_breast_cancer, id_vars="diagnosis", var_name="features", value_name='value')

    worst_breast_cancer = pd.concat([y, x_.iloc[:, 20:30]], axis=1)
    worst_breast_cancer = pd.melt(worst_breast_cancer, id_vars="diagnosis", var_name="features", value_name='value')

    # Box plot for detecting outlier for the se_features

    plt.figure(figsize=(10, 10))
    sns.boxplot(x="features", y="value", hue="diagnosis", data=se_breast_cancer, palette=colors)
    plt.xticks(rotation=90)
    st.pyplot()

    st.write("Visualizing the box plot of mean data set :")
    # Box plot for detecting outlier for the mean_features

    plt.figure(figsize=(10, 10))
    sns.boxplot(x="features", y="value", hue="diagnosis", data=mean_breast_cancer, palette=colors)
    plt.xticks(rotation=90)
    st.pyplot()

    st.write("Visualizing the box plot of worst data set :")
    # Box plot for detecting outlier for the worst_features

    plt.figure(figsize=(10, 10))
    sns.boxplot(x="features", y="value", hue="diagnosis", data=worst_breast_cancer, palette=colors)
    plt.xticks(rotation=90)
    st.pyplot()

    st.write("Visualizing the swarm plot of se data set :")
    plt.figure(figsize=(10, 10))
    sns.swarmplot(x="features", y="value", hue="diagnosis", data=se_breast_cancer, palette=colors)
    plt.xticks(rotation=90)
    st.pyplot()

    st.write("Visualizing the swarm plot of mean data set :")
    plt.figure(figsize=(10, 10))
    sns.swarmplot(x="features", y="value", hue="diagnosis", data=mean_breast_cancer, palette=colors)
    plt.xticks(rotation=90)
    st.pyplot()

    st.write("Visualizing the swarm plot of worst data set :")
    plt.figure(figsize=(10, 10))
    sns.swarmplot(x="features", y="value", hue="diagnosis", data=worst_breast_cancer, palette=colors)
    plt.xticks(rotation=90)
    st.pyplot()

    st.write("Visualizing the violin plot of se data set :")
    plt.figure(figsize=(10, 10))
    sns.violinplot(x="features", y="value", hue="diagnosis", data=se_breast_cancer, palette=colors)
    plt.xticks(rotation=90)
    st.pyplot()

    st.write("Visualizing the violin plot of mean data set :")
    plt.figure(figsize=(10, 10))
    sns.violinplot(x="features", y="value", hue="diagnosis", data=mean_breast_cancer, palette=colors)
    plt.xticks(rotation=90)
    st.pyplot()

    st.write("Visualizing the violin plot of worst data set :")
    plt.figure(figsize=(10, 10))
    sns.violinplot(x="features", y="value", hue="diagnosis", data=worst_breast_cancer, palette=colors)
    plt.xticks(rotation=90)
    st.pyplot()

# Visualizing Data Group 3
if function == "Data Visualizations Group 3":
    y = data.diagnosis
    x = data.drop(columns="diagnosis")

    # As we can see, our dataset has 3 categoriel features. We have mean, se and worst categories. So we will divide 3 categories all of features.
    # The mean, standard error and "worst" or largest (mean of the three largest values) of these features were computed for each image,
    # resulting in 30 features. For instance, field 3 is Mean Radius, field 13 is Radius SE, field 23 is Worst Radius.

    mean_data = ['radius_mean', 'texture_mean', 'perimeter_mean', 'area_mean', 'smoothness_mean', 'compactness_mean',
                 'concavity_mean', 'concave points_mean', 'symmetry_mean', 'fractal_dimension_mean']
    se_data = ['radius_se', 'texture_se', 'perimeter_se', 'area_se', 'smoothness_se', 'compactness_se', 'concavity_se',
               'concave points_se', 'symmetry_se', 'fractal_dimension_se']
    worst_data = ['radius_worst', 'texture_worst', 'perimeter_worst', 'area_worst', 'smoothness_worst',
                  'compactness_worst', 'concavity_worst', 'concave points_worst', 'symmetry_worst',
                  'fractal_dimension_worst']

    # After categorising, we will add our target values(diagnosis/ y) in 3 equals
    x_ = (x - x.mean()) / x.std()  # standardization to group all similar (se, mean and worst features together)

    colors = ["red", "green"]
    mean_breast_cancer = pd.concat([y, x_.iloc[:, 0:10]], axis=1)
    mean_breast_cancer = pd.melt(mean_breast_cancer, id_vars="diagnosis", var_name="features", value_name='value')

    se_breast_cancer = pd.concat([y, x_.iloc[:, 10:20]], axis=1)
    se_breast_cancer = pd.melt(se_breast_cancer, id_vars="diagnosis", var_name="features", value_name='value')

    worst_breast_cancer = pd.concat([y, x_.iloc[:, 20:30]], axis=1)
    worst_breast_cancer = pd.melt(worst_breast_cancer, id_vars="diagnosis", var_name="features", value_name='value')

    st.write("Visualizing the pair plot of mean data set :")
    # Pair plot of mean data
    mean_data = pd.concat([y, x_.iloc[:, 0:5]], axis=1)
    sns.pairplot(mean_data, hue="diagnosis", palette=colors)
    plt.show()
    st.pyplot()

    st.write("Visualizing the pair plot of se data set :")
    se_data = pd.concat([y, x_.iloc[:, 10:15]], axis=1)
    sns.pairplot(se_data, hue="diagnosis", palette=colors)
    plt.show()  # Pair plot of se data
    st.pyplot()

    st.write("Visualizing the pair plot of worst data set :")
    # Pair plot of worst data set
    worst_data = pd.concat([y, x_.iloc[:, 20:25]], axis=1)
    sns.pairplot(worst_data, hue="diagnosis", palette=colors)
    plt.show()  # Pair plot of worst data
    st.pyplot()

    st.write("Viewing highly correlated features of 0.7")
    corr_matrix = data.corr()
    threshold = 0.7
    filtre = np.abs(corr_matrix.iloc[:, 0]) > threshold
    corr_features = corr_matrix.columns[filtre].tolist()
    sns.clustermap(data[corr_features].corr(), annot=True, fmt=".2f")
    st.pyplot()

    st.write("Viewing correlations of all features")
    plt.figure(figsize=(18, 18))
    sns.heatmap(data.corr(), annot=True)
    st.pyplot()


# Models Performances 1
# Performance measurement after removing outliers
if function == "Models Performances Result 1":
    st.write("Models Performances After Removing Outliers & Tuning Model")

    # Encode the diagnosis column (M=1, B=0)
    le = LabelEncoder()
    data['diagnosis'] = le.fit_transform(data['diagnosis'])

    def outliers(data, columns):
        outlier_indexes = []
        for i in columns:
            Q1 = data[i].quantile(0.25)
            Q3 = data[i].quantile(0.75)
            IQR = Q3 - Q1
            lower_limit = Q1 - 1.5 * IQR
            upper_limit = Q3 + 1.5 * IQR
            filter = ((data[i] < lower_limit) | (data[i] > upper_limit))
            outlier_observations = data[i][filter]
            outlier_indices = outlier_observations.index
            outlier_indexes.extend(outlier_indices)

        outlier_indexes = Counter(outlier_indexes)  # finds unique values and converts them into a dictionary
        common_indices = [i for i, v in outlier_indexes.items() if
                          v > 2]  # if there are more than two outliers at the same time, takes it for a row

        return common_indices

    delete_index = outliers(data, data.columns)
    data_new = data.drop(delete_index, axis=0).reset_index(drop=True)

    y = data_new.diagnosis.values.reshape(-1, 1)
    x = data_new.drop(["diagnosis"], axis=1)

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)
    sc = StandardScaler()
    x_train = sc.fit_transform(x_train)
    x_test = sc.transform(x_test)

    # ML Models
    classifier = [DecisionTreeClassifier(random_state=42),
                  SVC(random_state=42),
                  RandomForestClassifier(random_state=42),
                  LogisticRegression(random_state=42),
                  KNeighborsClassifier()]

    dt_param_grid = {"min_samples_split": range(10, 500, 20),
                     "max_depth": range(1, 20, 2)}

    svc_param_grid = {"kernel": ["rbf"],
                      "gamma": [0.001, 0.01, 0.1, 1],
                      "C": [1, 10, 50, 100, 200, 300, 1000]}

    rf_param_grid = {"max_features": [1, 3, 10],
                     "min_samples_split": [2, 3, 10],
                     "min_samples_leaf": [1, 3, 10],
                     "bootstrap": [False],
                     "n_estimators": [100, 300],
                     "criterion": ["gini"]}

    logreg_param_grid = {"C": np.logspace(-3, 3, 7),
                         "penalty": ["l1", "l2"]}

    knn_param_grid = {"n_neighbors": np.linspace(1, 19, 10, dtype=int).tolist(),
                      "weights": ["uniform", "distance"],
                      "metric": ["euclidean", "manhattan"]}

    # This code defines parameter grids for various machine learning algorithms used for hyperparameter tuning.

    classifier_params = [dt_param_grid,
                         svc_param_grid,
                         rf_param_grid,
                         logreg_param_grid,
                         knn_param_grid]

    # Load the best estimators and cross-validation results from the saved file
    with open("tuned_models.pickle", "rb") as f:
        best_estimators, cv_results = pickle.load(f)

    # Display the accuracy of the best estimator(s)
    for estimator, cv_result in zip(best_estimators, cv_results):
        st.write(f"{estimator.__class__.__name__} train accuracy: {cv_result:.4f}")



    # cv_results = []
    # best_estimators = []
    # for i in range(len(classifier)):
    #     grid = GridSearchCV(classifier[i], param_grid=classifier_params[i], cv=StratifiedKFold(n_splits=10),
    #                         scoring="accuracy", n_jobs=-1, verbose=1)
    #     model = grid.fit(x_train, y_train)
    #     cv_results.append(model.best_score_)
    #     best_estimators.append(model.best_estimator_)
    #     print(best_estimators[i])
    #     st.write(best_estimators[i])
    #     print(cv_results[i])
    #     st.write(f"train accuracy: {cv_results[i]}")

    st.write("Model Performance Rankings")
    # Pad cv_results with NaN values to make it of length 5
    cv_results_padded = cv_results + [np.nan] * (5 - len(cv_results))

    # Create the data_models DataFrame with padded cv_results
    data_models = pd.DataFrame({"Cross Validation": cv_results_padded,
                                    "ML Models": ["DT", "SVM", "RF", "LR", "KN"]})


    # Visualization
    sns.barplot(x="Cross Validation", y="ML Models",
                data=data_models.sort_values(["Cross Validation"], ascending=False))
    st.pyplot()



        # # Save the best estimators and cross-validation results to a file
        # with open("tuned_models.pickle", "wb") as f:
        #     pickle.dump((best_estimators, cv_results), f)

        # st.write("Displaying the Models Based on Performance")




    st.write("SVM Train, Test Accuracy & Confusion Matrix")
    grid = {"kernel": ["rbf"],
            "gamma": [0.001],
            "C": [100]}
    svm = SVC(random_state=42)
    svm_cv = GridSearchCV(svm, grid, cv=10, scoring="accuracy")
    model = svm_cv.fit(x_train, y_train)
    print("train accuracy:", format(model.best_score_, '.4f'))
    st.write(("train accuracy:", format(model.best_score_, '.4f')))

    y_svm = model.predict(x_test)
    test_accuracy = accuracy_score(y_test, y_svm)
    print("test accuracy:", format(test_accuracy, '.4f'))
    st.write(("test accuracy:", format(test_accuracy, '.4f')))

    svm_cm = confusion_matrix(y_test, y_svm)
    sns.heatmap(svm_cm, annot=True)
    st.pyplot()

    print(classification_report(y_test, y_svm))
    # display the classification report
    report = classification_report(y_test, y_svm)
    st.text_area("SVM Classification Report", value=report, height=200)

    st.write("LR Train, Test Accuracy & Confusion Matrix")

    grid_lr = {"C": np.logspace(start=0.1, stop=1, num=10, base=10)}
    lr = LogisticRegression(random_state=42)
    lr_cv = GridSearchCV(lr, grid_lr, cv=10, scoring="accuracy")
    model_lr = lr_cv.fit(x_train, y_train)
    print("train accuracy: {:.4f}".format(model_lr.best_score_))
    st.write(("train accuracy:", "{:.4f}".format(model_lr.best_score_)))

    y_lr = model_lr.predict(x_test)
    print("test accuracy: {:.4f}".format(accuracy_score(y_test, y_lr)))
    st.write(("test accuracy:", "{:.4f}".format(accuracy_score(y_test, y_lr))))

    lr_cm = confusion_matrix(y_test, y_lr)
    sns.heatmap(lr_cm, annot=True)
    st.pyplot()

    print(classification_report(y_test, y_lr))
    # display the classification report
    report = classification_report(y_test, y_lr)
    st.text_area("LR Classification Report", value=report, height=200)

    st.write("RF Train, Test Accuracy & Confusion Matrix")
    grid_rf = {"max_features": [10],
               "min_samples_split": [3],
               # "min_samples_leaf": [1, 3, 10],
               "bootstrap": [False],
               # "n_estimators": [100, 300],
               "criterion": ["gini"]}

    rf = RandomForestClassifier(random_state=42)
    rf_cv = GridSearchCV(rf, grid_rf, cv=10, scoring="accuracy")
    model_rf = rf_cv.fit(x_train, y_train)
    print("train accuracy:", model_rf.best_score_)
    st.write(("train accuracy:", model_rf.best_score_))

    y_rf = model_rf.predict(x_test)
    print("test accuracy:", accuracy_score(y_test, y_rf))
    st.write(("test accuracy:", accuracy_score(y_test, y_rf)))

    rf_cm = confusion_matrix(y_test, y_rf)
    sns.heatmap(rf_cm, annot=True)
    st.pyplot()

    print(classification_report(y_test, y_rf))
    # display the classification report
    report = classification_report(y_test, y_rf)
    st.text_area("RF Classification Report", value=report, height=200)

    st.write("KNN Train, Test Accuracy & Confusion Matrix")
    grid_knn = {"n_neighbors": np.linspace(start=1, stop=9, num=9, dtype=int).tolist(),
                "weights": ["uniform", "distance"],
                "metric": ["euclidean"]}

    knn = KNeighborsClassifier()
    knn_cv = GridSearchCV(knn, grid_knn, cv=10, scoring="accuracy")
    model_knn = knn_cv.fit(x_train, y_train)
    print("train accuracy:", model_knn.best_score_)
    st.write(("train accuracy:", model_knn.best_score_))

    y_knn = model_knn.predict(x_test)
    print("test accuracy:", accuracy_score(y_test, y_knn))
    st.write(("test accuracy:", accuracy_score(y_test, y_knn)))

    knn_cm = confusion_matrix(y_test, y_knn)
    sns.heatmap(knn_cm, annot=True)
    st.pyplot()

    print(classification_report(y_test, y_knn))
    # display the classification report
    report = classification_report(y_test, y_knn)
    st.text_area("KNN Classification Report", value=report, height=200)

    st.write("DT Train, Test Accuracy & Confusion Matrix")
    grid_dt = {"max_depth": [9], "min_samples_split": [10]}

    dt = DecisionTreeClassifier(random_state=42)
    dt_cv = GridSearchCV(dt, grid_dt, cv=10, scoring="accuracy")
    model_dt = dt_cv.fit(x_train, y_train)
    print("train accuracy:", model_dt.best_score_)
    st.write(("train accuracy:", model_dt.best_score_))

    y_dt = model_dt.predict(x_test)
    print("test accuracy:", accuracy_score(y_test, y_dt))
    st.write(("test accuracy:", accuracy_score(y_test, y_dt)))

    dt_cm = confusion_matrix(y_test, y_dt)
    sns.heatmap(dt_cm, annot=True)
    st.pyplot()

    print(classification_report(y_test, y_dt))
    # display the classification report
    report = classification_report(y_test, y_dt)
    st.text_area("DT Classification Report", value=report, height=200)


# Models Performances 2
# Performance measurement using optimal number of features
if function == "Models Performances Result 2":


    y = data['diagnosis']
    X = data[['radius_mean', 'texture_mean', 'perimeter_mean', 'area_mean', 'smoothness_mean', 'compactness_mean',
              'concavity_mean',
              'concave points_mean', 'symmetry_mean', 'fractal_dimension_mean', 'radius_se', 'texture_se',
              'perimeter_se', 'area_se', 'smoothness_se',
              'compactness_se', 'concavity_se', 'concave points_se', 'symmetry_se', 'fractal_dimension_se',
              'radius_worst', 'texture_worst', 'perimeter_worst', 'area_worst',
              'smoothness_worst', 'compactness_worst', 'concavity_worst', 'concave points_worst', 'symmetry_worst',
              'fractal_dimension_worst']]

    # Encode the diagnosis column (M=1, B=0)
    le = LabelEncoder()
    data['diagnosis'] = le.fit_transform(data['diagnosis'])

    # Dimensionality reduction (from the highly correlated features)

    # The following features are the most related (corr>9) to other features (radius_mean, perimeter_mean, area_mean,
    # radius_worst, perimeter_worst)

    # The features with high correlation with other features are: (threshold = 90%)

    high_corr_pts = X[['radius_mean', 'perimeter_mean', 'area_mean', 'radius_worst', 'perimeter_worst']]


    # Splitting of data into test and train set
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # st.write("XGboost Accuracy Using All Features")
    st.write("<span style='color:red'>XGboost Accuracy Using All Features</span>", unsafe_allow_html=True)

    # # Define the parameter grid to search over
    # param_grid = {
    #     'max_depth': [3, 5, 7],
    #     'learning_rate': [0.01, 0.1, 0.5],
    #     'n_estimators': [100, 200, 300],
    #     'gamma': [0, 0.1, 0.2]
    # }
    #
    # # Create a XGBClassifier object
    # xgb_model = xgb.XGBClassifier()
    #
    # # Create a GridSearchCV object
    # grid_search = GridSearchCV(estimator=xgb_model, param_grid=param_grid, cv=5)
    #
    # # Fit the GridSearchCV object to the data
    # grid_search.fit(X_train, y_train)
    #
    # # Print the best hyperparameters and the corresponding score
    # st.write("Best parameters: ", grid_search.best_params_)
    # st.write("Best score: ", grid_search.best_score_)

    # model_all = xgb.XGBClassifier()
    # model_all.fit(X_train, y_train)
    #
    # train_pred = model_all.predict(X_train)  # Predicting output labels for X_train
    # train_accuracy = accuracy_score(y_train, train_pred)  # Comparing predicted labels with actual labels for X_train
    #
    # st.write("Train Accuracy Score:", train_accuracy)
    #
    # test_pred = model_all.predict(X_test)
    #
    # # Analysing the predictions
    #
    # test_accuracy = accuracy_score(y_test, test_pred)
    # st.write("Test Accuracy Score:", test_accuracy)
    #
    # xg_cm = confusion_matrix(y_test, test_pred)
    # sns.heatmap(xg_cm, annot=True)
    # st.pyplot()
    #
    #
    # # XGBoost Classification Report
    #
    # XG_report = classification_report(y_test, test_pred)
    # st.text_area("XGBoost Classification Report", value=XG_report, height=200)

    # Finding the optimal features


    # Creating and fitting the XGBoost model
    # model_all = xgb.XGBClassifier(gamma=0, learning_rate=0.1, max_depth=5, n_estimators=200)
    # model_all.fit(X_train, y_train)

    # Saving the model
    # joblib.dump(model_all, 'xgb_model.pkl')
    # Set a random seed for the train-test split and XGBoost algorithm


    # Loading the saved model
    model_all = joblib.load('xgb_model.pkl')

    # Set the random state parameter
    model_all.set_params(random_state=42)

    # Predicting output labels for X_train
    train_pred = model_all.predict(X_train)

    # Comparing predicted labels with actual labels for X_train
    train_accuracy = accuracy_score(y_train, train_pred)

    # Printing the train accuracy score
    print("Train Accuracy Score:", train_accuracy)
    st.write("Train Accuracy Score:", round(train_accuracy, 4))


    # Predicting output labels for X_test
    test_pred = model_all.predict(X_test)

    # Calculating test accuracy score
    test_accuracy = accuracy_score(y_test, test_pred)

    # Printing the test accuracy score
    print("Test Accuracy Score:", test_accuracy)
    st.write("Test Accuracy Score:", round(test_accuracy, 4))


    # Confusion matrix heatmap
    xg_cm = confusion_matrix(y_test, test_pred)
    sns.heatmap(xg_cm, annot=True, fmt="d")
    plt.show()
    st.pyplot()

    print(classification_report(y_test, test_pred))
    # display the classification report
    xg_report = classification_report(y_test, test_pred)
    st.text_area("XG Classification Report", value=xg_report, height=200)

    st.write("<span style='color:red'>XGboost Accuracy Using Optimal Features</span>", unsafe_allow_html=True)
    # Finding the optimal features
    # The 'accuracy' scoring is proportional to the number of correct classification
    clf = xgb.XGBClassifier()
    rfecv = RFECV(estimator=clf, step=1, cv=4, scoring='accuracy')  # 5 fold cross validation
    rfecv = rfecv.fit(X_train, y_train)

    print('Optimal number of features :', rfecv.n_features_)
    st.write('Optimal number of features :', rfecv.n_features_)
    print('Best features :', X_train.columns[rfecv.support_])
    st.write('Best features :', X_train.columns[rfecv.support_])


    # 23 optimal features are selected
    # We proceed to plot the number of features vs cross validation scores to see how it ffects the prediction:

    # Plotting the cross validation scores vs number of features
    plt.figure()
    plt.title('Optimal number of features')
    plt.xlabel("Number of features selected")
    plt.ylabel("Cross validation score")
    plt.plot(range(1, len(rfecv.grid_scores_) + 1), rfecv.grid_scores_)
    st.pyplot()

    # Feature ranking with recursive feature elimination and cross-validated selection of the best number of features
    importance = (model_all.feature_importances_)
    indices = np.argsort(importance)[::-1]
    # Plot to rank the features importances
    plt.title("Feature importances")
    plt.bar(range(X_train.shape[1]), importance[indices], color="g", align="center")
    plt.xticks(range(X_train.shape[1]), X_train.columns[indices], rotation=90)
    plt.xlim([-1, X_train.shape[1]])
    plt.show()
    st.pyplot()

    # Training and analyzing the model with only the optimal features

    X_train_optimal = X_train[['radius_mean', 'texture_mean',
                                'concavity_mean', 'concave points_mean',
                                'symmetry_mean', 'smoothness_se','radius_se',
                               'fractal_dimension_se','texture_se', 'area_se','compactness_se', 'concavity_se', 'fractal_dimension_worst',
                               'radius_worst', 'texture_worst', 'perimeter_worst', 'area_worst', 'smoothness_worst',
                                'concavity_worst', 'concave points_worst']]
    # 'smoothness_mean', 'fractal_dimension_mean', 'compactness_worst',
    X_test_optimal = X_test[['radius_mean', 'texture_mean',
                                'concavity_mean', 'concave points_mean',
                                'symmetry_mean', 'smoothness_se','radius_se',
                               'fractal_dimension_se','texture_se', 'area_se','compactness_se','concavity_se', 'fractal_dimension_worst',
                               'radius_worst', 'texture_worst', 'perimeter_worst', 'area_worst', 'smoothness_worst',
                                'concavity_worst', 'concave points_worst']]


    # Load classifier in model optimal (considering all optimal features)
    model_optimal = xgb.XGBClassifier(gamma=0, learning_rate=0.1, max_depth=5, n_estimators=200)

    # Set the random state parameter
    model_optimal.set_params(random_state=42)

    # Fit model on optimal features
    model_optimal.fit(X_train_optimal, y_train)

    # Predicting output labels for X_train
    pred_train = model_optimal.predict(X_train_optimal)

    # Comparing predicted labels with actual labels for X_train
    train_accuracy = accuracy_score(y_train, pred_train)

    # Printing the train accuracy score
    print("Train Accuracy Score:", train_accuracy)
    st.write("Train Accuracy Score:", train_accuracy)

    # Predicting output labels for X_test
    pred_test = model_optimal.predict(X_test_optimal)

    # Calculating test accuracy score
    test_accuracy = accuracy_score(y_test, pred_test)

    # Printing the test accuracy score
    print("Test Accuracy Score: {:.4f}".format(test_accuracy))
    st.write("Test Accuracy Score: {:.4f}".format(test_accuracy))

    # Confusion matrix heatmap
    xgb_cm = confusion_matrix(y_test, pred_test)
    sns.heatmap(xgb_cm, annot=True, fmt="d")
    plt.show()
    st.pyplot()

    print(classification_report(y_test, pred_test))
    # display the classification report
    xgb_report = classification_report(y_test, pred_test)
    st.text_area("XG Classification Report", value=xgb_report, height=200)

# Models Performances 3
# Performance measurement using optimal number of features
if function == "Models Performances Result 3":
    st.write("<span style='color:red'>Model Performance After Removing Multicollinearity Features</span>", unsafe_allow_html=True)

    # Categorizing the features

    # As we can see, our dataset has 3 categoriel features. We have mean, se and worst categories. So we will divide 3 categories all of features.
    # The mean, standard error and "worst" or largest (mean of the three largest values) of these features were computed for each image,
    # resulting in 30 features. For instance, field 3 is Mean Radius, field 13 is Radius SE, field 23 is Worst Radius.

    # Encode the diagnosis column (M=1, B=0)
    le = LabelEncoder()
    data['diagnosis'] = le.fit_transform(data['diagnosis'])


    mean_data = ['radius_mean', 'texture_mean', 'perimeter_mean', 'area_mean', 'smoothness_mean', 'compactness_mean',
                 'concavity_mean', 'concave points_mean', 'symmetry_mean', 'fractal_dimension_mean']
    se_data = ['radius_se', 'texture_se', 'perimeter_se', 'area_se', 'smoothness_se', 'compactness_se', 'concavity_se',
               'concave points_se', 'symmetry_se', 'fractal_dimension_se']
    worst_data = ['radius_worst', 'texture_worst', 'perimeter_worst', 'area_worst', 'smoothness_worst',
                  'compactness_worst', 'concavity_worst', 'concave points_worst', 'symmetry_worst',
                  'fractal_dimension_worst']

    y = data.diagnosis
    x = data.drop(columns="diagnosis")
    x_ = (x - x.mean()) / x.std()  # standardization to group all similar (se, mean and worst features together)

    # After categorising, we will add our target values(diagnosis/ y) in 3 equels¶

    # Generate and visualize the correlation matrix
    corr = data.corr().round(2)

    # Mask the upper triangle
    mask = np.zeros_like(corr, dtype=np.bool)
    mask[np.triu_indices_from(mask)] = True

    # Set figure size
    f, ax = plt.subplots(figsize=(20, 20))

    # Define custom colourmap
    colors_list = [(0, "#4575b4"), (0.5, "#f7f7f7"), (1, "#d73027")]  # define the colors for the color map
    cmap_custom = colors.LinearSegmentedColormap.from_list("CustomMap", colors_list)  # create the custom color map

    # Draw the heatmap with the custom color map
    sns.heatmap(corr, mask=mask, cmap=cmap_custom, vmin=-1, vmax=1, center=0, square=True,
                linewidths=.5, cbar_kws={"shrink": 0.5}, annot=True)

    plt.tight_layout()
    st.pyplot()

    st.write("<span style='color:red'>Removing Multicollinear Features</span>",
             unsafe_allow_html=True)

    # first, drop all the worst columns

    data = data.drop(worst_data, axis=1)

    # then, drop all the columns related to the 'perimeter' and 'area' attributes

    data2 = ['perimeter_mean',
             'perimeter_se',
             'area_mean', 'area_se']

    data = data.drop(data2, axis=1)

    # lastly, drop all columns related to the concavity and concave_points

    data3 = ['concavity_mean',
             'concavity_se',
             'concave points_mean',
             'concave points_se']

    data = data.drop(data3, axis=1)


    # Redraw the correlation map to check

    # Generate and visualize the correlation matrix
    corr = data.corr().round(2)

    # Mask the upper triangle
    mask = np.zeros_like(corr, dtype=np.bool)
    mask[np.triu_indices_from(mask)] = True

    # Set figure size
    f, ax = plt.subplots(figsize=(20, 20))

    # Define custom colourmap
    colors_list = [(0, "#4575b4"), (0.5, "#f7f7f7"), (1, "#d73027")]  # define the colors for the color map
    cmap_custom = colors.LinearSegmentedColormap.from_list("CustomMap", colors_list)  # create the custom color map

    # Draw the heatmap with the custom color map
    sns.heatmap(corr, mask=mask, cmap=cmap_custom, vmin=-1, vmax=1, center=0, square=True,
                linewidths=.5, cbar_kws={"shrink": 0.5}, annot=True)

    plt.tight_layout()
    st.pyplot()

    # Building The Model
    # First drop the diagnosis column
    X = data.drop(['diagnosis'], axis=1)
    y = data['diagnosis']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=40)

    ss = StandardScaler()

    X_train = ss.fit_transform(X_train)
    X_test = ss.fit_transform(X_test)

    st.write("<span style='color:red'>Logistic Regression Accuracy Score</span>",
             unsafe_allow_html=True)

    # Logistic Regression Model
    # lr = LogisticRegression()
    C = 0.1  # Set the value of C to a single value
    lr = LogisticRegression(C=C, random_state=42)

    model1 = lr.fit(X_train, y_train)
    prediction1 = model1.predict(X_test)

    print("LR test accuracy:", accuracy_score(y_test, prediction1))
    st.write("LR test accuracy:", accuracy_score(y_test, prediction1))

    lr1_cm = confusion_matrix(y_test, prediction1)
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(lr1_cm, annot=True,fmt="d", annot_kws={"fontsize": 14})
    st.pyplot()


    print(classification_report(y_test, prediction1))
    # display the classification report
    lr_report = classification_report(y_test, prediction1)
    st.text_area("LR Classification Report", value=lr_report, height=200)

    st.write("<span style='color:red'>Decision Tree Accuracy Score</span>",
             unsafe_allow_html=True)

    dtc = DecisionTreeClassifier(max_depth=9, min_samples_split=10, random_state=42)
    model2 = dtc.fit(X_train, y_train)
    prediction2 = model2.predict(X_test)

    print("DT test accuracy:", accuracy_score(y_test, prediction2))
    st.write("DT test accuracy:", accuracy_score(y_test, prediction2))

    DT1_cm = confusion_matrix(y_test, prediction2)
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(DT1_cm, annot=True, fmt="d", annot_kws={"fontsize": 14})
    st.pyplot()

    print(classification_report(y_test, prediction2))
    # display the classification report
    lr_report = classification_report(y_test, prediction2)
    st.text_area("DT Classification Report", value=lr_report, height=200)

    st.write("<span style='color:red'>Random Forest Accuracy Score</span>",
             unsafe_allow_html=True)

    # Instantiate the model with the given hyperparameters
    rfc = RandomForestClassifier(bootstrap=False, max_features=10, min_samples_split=3, random_state=42)

    # Fit the model on the training data
    model3 = rfc.fit(X_train, y_train)

    # Make predictions on the test data
    prediction3 = model3.predict(X_test)

    print("RF test accuracy:", accuracy_score(y_test, prediction3))
    st.write("RF test accuracy:", accuracy_score(y_test, prediction3))

    RF1_cm = confusion_matrix(y_test, prediction3)
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(RF1_cm, annot=True, fmt="d", annot_kws={"fontsize": 14})
    st.pyplot()

    print(classification_report(y_test, prediction3))
    # display the classification report
    rf_report = classification_report(y_test, prediction3)
    st.text_area("RF Classification Report", value=rf_report, height=200)

    st.write("<span style='color:red'>KNN Accuracy Score</span>",
             unsafe_allow_html=True)


    knc = KNeighborsClassifier(metric='euclidean', n_neighbors=9)
    model4 = knc.fit(X_train, y_train)
    prediction4 = model4.predict(X_test)

    print("KNN test accuracy:", accuracy_score(y_test, prediction4))
    st.write("KNN test accuracy:", accuracy_score(y_test, prediction4))

    KNN1_cm = confusion_matrix(y_test, prediction4)
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(KNN1_cm, annot=True, fmt="d", annot_kws={"fontsize": 14})
    st.pyplot()

    print(classification_report(y_test, prediction4))
    # display the classification report
    KNN_report = classification_report(y_test, prediction4)
    st.text_area("KNN Classification Report", value=KNN_report, height=200)

    st.write("<span style='color:red'>Support Vector Accuracy Score</span>",
             unsafe_allow_html=True)

    svc = SVC(random_state=42)
    scores_svc = cross_val_score(svc, X, y, cv=10, scoring='accuracy')

    model5 = svc.fit(X_train, y_train)
    prediction5 = model5.predict(X_test)
    accuracy_score(y_test, prediction5)


    print("SVC test accuracy:", accuracy_score(y_test, prediction5))
    st.write("SVC test accuracy:", accuracy_score(y_test, prediction5))

    SVC1_cm = confusion_matrix(y_test, prediction5)
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(SVC1_cm, annot=True, fmt="d", annot_kws={"fontsize": 14})
    st.pyplot()

    print(classification_report(y_test, prediction5))
    # display the classification report
    SVC_report = classification_report(y_test, prediction5)
    st.text_area("SVC Classification Report", value=SVC_report, height=200)


# Predicting Cancer Types
# Designing a Model That Predicts the Cancer Type from the non highly linear features
if function == "Predicting Cancer Types":
    st.write("<span style='color:red'>Predicting Cancer Type After Removing Multicollinear Features</span>", unsafe_allow_html=True)
    # Allow users to enter the details for the features and to get necessary information


    feature_names = "radius_mean, texture_mean, smoothness_mean, compactness_mean, symmetry_mean, fractal_dimension_mean, radius_se, texture_se, smoothness_se, compactness_se, symmetry_se, fractal_dimension_se"

    st.write("Feature names: ", feature_names)

    # Loading the data
    data = pd.read_csv('breast-cancer-wisconsin-data.csv')  # read in the data

    # Drop the ID column
    data.drop('id', axis=1, inplace=True)

    # Encoding the diagnosis column
    # Encode the diagnosis column (M=1, B=0)
    le = LabelEncoder()
    data['diagnosis'] = le.fit_transform(data['diagnosis'])

    # Categorizing the features

    # As we can see, our dataset has 3 categoriel features. We have mean, se and worst categories. So we will divide 3 categories all of features.
    # The mean, standard error and "worst" or largest (mean of the three largest values) of these features were computed for each image,
    # resulting in 30 features. For instance, field 3 is Mean Radius, field 13 is Radius SE, field 23 is Worst Radius.

    mean_data = ['radius_mean', 'texture_mean', 'perimeter_mean', 'area_mean', 'smoothness_mean', 'compactness_mean',
                 'concavity_mean', 'concave points_mean', 'symmetry_mean', 'fractal_dimension_mean']
    se_data = ['radius_se', 'texture_se', 'perimeter_se', 'area_se', 'smoothness_se', 'compactness_se', 'concavity_se',
               'concave points_se', 'symmetry_se', 'fractal_dimension_se']
    worst_data = ['radius_worst', 'texture_worst', 'perimeter_worst', 'area_worst', 'smoothness_worst',
                  'compactness_worst', 'concavity_worst', 'concave points_worst', 'symmetry_worst',
                  'fractal_dimension_worst']

    # After categorising, we will add our target values(diagnosis/ y) in 3 equels¶

    y = data.diagnosis
    x = data.drop(columns="diagnosis")
    x_ = (x - x.mean()) / x.std()  # standardization to group all similar (se, mean and worst features together)

    colors = ["red", "green"]
    mean_breast_cancer = pd.concat([y, x_.iloc[:, 0:10]], axis=1)
    mean_breast_cancer = pd.melt(mean_breast_cancer, id_vars="diagnosis", var_name="features", value_name='value')

    se_breast_cancer = pd.concat([y, x_.iloc[:, 10:20]], axis=1)
    se_breast_cancer = pd.melt(se_breast_cancer, id_vars="diagnosis", var_name="features", value_name='value')

    worst_breast_cancer = pd.concat([y, x_.iloc[:, 20:30]], axis=1)
    worst_breast_cancer = pd.melt(worst_breast_cancer, id_vars="diagnosis", var_name="features", value_name='value')

    # first, drop all the worst columns

    data = data.drop(worst_data, axis=1)

    # then, drop all the columns related to the 'perimeter' and 'area' attributes

    data2 = ['perimeter_mean',
             'perimeter_se',
             'area_mean', 'area_se']

    data = data.drop(data2, axis=1)

    # lastly, drop all columns related to the concavity and concave_points

    data3 = ['concavity_mean',
             'concavity_se',
             'concave points_mean',
             'concave points_se']

    data = data.drop(data3, axis=1)

    # First drop the diagnosis column
    X = data.drop(['diagnosis'], axis=1)
    y = data['diagnosis']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=40)

    ss = StandardScaler()

    X_train = ss.fit_transform(X_train)
    X_test = ss.fit_transform(X_test)

    # model = SVC(kernel='linear', C=1)

    # Train the model on your data
    # model.fit(X_train, y_train)
    # Save the trained model
    # joblib.dump(model, 'my_model.pkl')

    # load the trained model
    loaded_model = joblib.load('my_model.pkl')

    st.write("<span style='color:red'>Predict Cancer Type </span>",
             unsafe_allow_html=True)

    # get the input data from the user using Streamlit's input function
    input_data = st.text_input("Enter the values of the 12 features above separated by commas: ")

    if input_data:
        # convert the input data into a numpy array
        input_data_array = np.asarray(tuple(map(float, input_data.split(','))))

        # reshape the numpy array as we are predicting for one datapoint
        input_data_reshaped = input_data_array.reshape(1, -1)

        # make a prediction on the input data
        prediction = loaded_model.predict(input_data_reshaped)

        # display the prediction result using Streamlit's write function
        if prediction[0] == 1:
            st.write("The Breast cancer is Malignant")
        else:
            st.write("The Breast cancer is Benign")








































