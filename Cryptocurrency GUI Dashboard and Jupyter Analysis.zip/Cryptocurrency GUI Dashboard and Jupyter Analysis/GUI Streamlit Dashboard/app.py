import numpy as np
import pandas as pd
import streamlit as st
import yfinance as yf
import datetime as dt
import pytz
from PIL import Image
import plotly.graph_objs as go
import matplotlib.pyplot as plt
import seaborn as sns
from keras.models import load_model
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score

image = Image.open('Soligence logo.jpg')

st.image(image, caption=None, width=200, use_column_width=150)


# Map coin names to ticker symbols
coin_map = {
    "Bitcoin": "BTC-USD",
    "Ethereum": "ETH-USD",
    "Ripple": "XRP-USD",
    "Tether": "USDT-USD",
    "Solana": "SOL-USD",
    "Cardano": "ADA-USD",
    "Polkadot": "DOT-USD",
    "XRP": "XRP-USD",
    "Dogecoin": "DOGE-USD",
    "Avalanche": "AVAX-USD",
    "USD Coin": "USDC-USD",
    "Cosmos": "ATOM-USD",
    "Algorand": "ALGO-USD",
    "Shiba Inu": "SHIB-USD",
    "Bitcoin Cash": "BCH-USD",
    "Cronos": "CRO-USD",
    "Litecoin": "LTC-USD",
    "FTX Token": "FTT-USD",
    "SushiSwap": "SUSHI-USD",
    "Filecoin": "FIL-USD",
    "VeChain": "VET-USD",
    "Dai": "DAI-USD",
    "BitTorrent": "BTTOLD-USD",
    "Ren": "REN-USD",
    "Zcash": "ZEC-USD",
    "NEM" : "XEM-USD",
    "Theta Network": "THETA-USD",
    "Waves" : "WAVES-USD",
    "Serum" : "SRM-USD",
    "Kusama" : "KSM-USD",
    "Maker" : "MKR-USD",
    "Harmony": "ONE-USD",
    "PancakeSwap": "CAKE-USD",

}


# Extracting real-time data for the selected coin from Yahoo Finance
coin = st.sidebar.selectbox("Select Coin", ("Bitcoin", "Ethereum", "Ripple","Tether","Solana", "Cardano","Polkadot",
                                            "XRP","Dogecoin","Avalanche","USD Coin","Cosmos","Algorand","Shiba Inu",
                                            "Bitcoin Cash","Cronos","Litecoin","FTX Token","SushiSwap", "Filecoin",
                                            "VeChain", "Dai", "BitTorrent","Ren","Zcash","NEM","Theta Network","Maker",
                                            "Harmony","PancakeSwap", "Waves","Serum","Kusama"))


ticker = coin_map[coin]
if ticker is None:
    st.error("Selected coin is currently not available. Please select another coin.")
else:
    try:
        start = dt.datetime(2021, 1, 1)
        end = dt.datetime.now()
        df = yf.download(ticker, start=start, end=end)
    except Exception as e:
            st.error(f"Try later as an error occurred while trying to download data for {coin}: {e}")


# Display the selected coin name next to the subheader
st.subheader(f"Soligence IST Dashboard - {coin}")

# Setting the timezone of the index to UTC
df.index = df.index.tz_localize(pytz.utc)

# Displaying the data in a table format
st.dataframe(df.iloc[-7:][::-1])

# Create function to display sidebar widget


def display_sidebar_widgets(df):
    try:

        fig, ax = plt.subplots(figsize=(12, 6))
        ax.plot(df.Close, label='Close Value')
        ax.set_xlabel("Date")
        ax.set_ylabel("Close Value")
        ax.set_title("Close Value vs Time Graph")
        ax.legend(loc='best')
        st.pyplot(fig)

        # Calculate and plot 7 and 30 days moving average
        ma7 = df['Close'].rolling(7).mean()
        ma30 = df['Close'].rolling(30).mean()
        fig, ax = plt.subplots(figsize=(12, 6))
        ax.plot(df.Close, label='Close Price')
        ax.plot(ma7, 'r', label='7-day MA')
        ax.plot(ma30, 'g', label='30-day MA')
        ax.set_xlabel("Date")
        ax.set_ylabel("Close Value")
        ax.set_title("Close Price vs Time chart with 7 and 30MA")
        ax.legend()
        st.pyplot(fig)

        # Calculate and plot 7, 30 and 90 days moving average
        ma7 = df['Close'].rolling(7).mean()
        ma30 = df['Close'].rolling(30).mean()
        ma90 = df['Close'].rolling(90).mean()
        fig, ax = plt.subplots(figsize=(12, 6))
        ax.plot(df.Close, label='Close Price')
        ax.plot(ma7, 'r', label='7-day MA')
        ax.plot(ma30, 'g', label='30-day MA')
        ax.plot(ma90, 'b', label='90-day MA')
        ax.set_xlabel("Date")
        ax.set_ylabel("Close Value")
        ax.set_title("Close Price vs Time chart with 7, 30 and 90-day MA")
        ax.legend()
        st.pyplot(fig)
    except Exception as e:
        st.error("An error occurred while displaying the charts. Error message: {}".format(str(e)))

    # Predicting the next day close value using the last 60 days data
    try:
        # Training the data
        start = dt.datetime(2021, 1, 1)
        end = dt.datetime(2022, 1, 1)
        df = yf.download(ticker, start=start, end=end)

        # Prepare data
        scaler = MinMaxScaler(feature_range=(0, 1))
        scaled_data = scaler.fit_transform(df['Close'].values.reshape(-1, 1))

        prediction_days = 60

        future_day = 1

        x_train, y_train = [], []

        for x in range(prediction_days, len(scaled_data) - future_day):
            x_train.append(scaled_data[x - prediction_days:x, 0])
            y_train.append(scaled_data[x + future_day, 0])

        x_train, y_train = np.array(x_train), np.array(y_train)
        x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1], 1))

        # Load my model
        model = load_model('keras5n_model.h5')

        # Testing the model

        test_start = dt.datetime(2022, 1, 2)
        test_end = dt.datetime.now()

        test_data = yf.download(ticker, start=test_start, end=test_end)
        actual_prices = test_data['Close'].values


        total_dataset = pd.concat((df['Close'], test_data['Close']), axis=0)

        model_inputs = total_dataset[len(total_dataset) - len(test_data) - prediction_days:].values
        model_inputs = model_inputs.reshape(-1, 1)
        model_inputs = scaler.fit_transform(model_inputs)

        x_test = []
        for x in range(prediction_days, len(model_inputs)):
            x_test.append(model_inputs[x - prediction_days:x, 0])

        x_test = np.array(x_test)
        x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1))

        prediction_prices = model.predict(x_test)
        prediction_prices = scaler.inverse_transform(prediction_prices)

        fig = plt.figure(figsize=(12, 6))
        plt.title("Next day prediction from last 60 close values")
        plt.plot(actual_prices, color='blue', label='Actual Prices')
        plt.plot(prediction_prices, color='red', label='Predicted Prices')
        plt.xlabel('Time')
        plt.ylabel('Price')
        plt.legend(loc='upper right')
        plt.show()
        st.pyplot(fig)

        # Predict next day's price and accuracy score
        real_data = [model_inputs[len(model_inputs) + 1 - prediction_days: len(model_inputs) + 1, 0]]
        real_data = np.array(real_data)
        real_data = np.reshape(real_data, (real_data.shape[0], real_data.shape[1], 1))

        prediction = model.predict(real_data)
        prediction = scaler.inverse_transform(prediction)

        actual_price = df['Close'][-1]
        predicted_price = prediction[0][0]

        accuracy_score = r2_score(actual_prices, prediction_prices)

        # Display predicted price and accuracy score
        st.write(f"Next day's predicted price using LSTM: {predicted_price:.2f}")
        st.write(f"R-squared Score: {accuracy_score:.2f}")
    except Exception as e:
        st.error("Try later as an error occurred displaying the results. Error message: {}".format(str(e)))

    # Predicting the future 7th day close value using the last 60 days data
    try:
        # Training the data
        start = dt.datetime(2021, 1, 1)
        end = dt.datetime(2022, 1, 1)
        df = yf.download(ticker, start=start, end=end)

        # Prepare data
        scaler = MinMaxScaler(feature_range=(0, 1))
        scaled_data = scaler.fit_transform(df['Close'].values.reshape(-1, 1))

        prediction_days = 60

        future_day = 7

        x_train, y_train = [], []

        for x in range(prediction_days, len(scaled_data) - future_day):
            x_train.append(scaled_data[x - prediction_days:x, 0])
            y_train.append(scaled_data[x + future_day, 0])

        x_train, y_train = np.array(x_train), np.array(y_train)
        x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1], 1))

        # load model
        model = load_model('keras6n_model.h5')

        # Testing the model

        test_start = dt.datetime(2022, 1, 2)
        test_end = dt.datetime.now()

        test_data = yf.download(ticker, start=test_start, end=test_end)
        actual_prices = test_data['Close'].values

        total_dataset = pd.concat((df['Close'], test_data['Close']), axis=0)

        model_inputs = total_dataset[len(total_dataset) - len(test_data) - prediction_days:].values
        model_inputs = model_inputs.reshape(-1, 1)
        model_inputs = scaler.fit_transform(model_inputs)

        x_test = []
        for x in range(prediction_days, len(model_inputs)):
            x_test.append(model_inputs[x - prediction_days:x, 0])

        x_test = np.array(x_test)
        x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1))

        prediction_prices = model.predict(x_test)
        prediction_prices = scaler.inverse_transform(prediction_prices)

        fig = plt.figure(figsize=(12, 6))
        plt.title("Future 7th day prediction from last 60 close values")
        plt.plot(actual_prices, color='blue', label='Actual Prices')
        plt.plot(prediction_prices, color='red', label='Predicted Prices')
        plt.xlabel('Time')
        plt.ylabel('Price')
        plt.legend(loc='upper right')
        plt.show()
        st.pyplot(fig)

        # Predict future 7th day's price and accuracy score
        real_data = [model_inputs[len(model_inputs) + 7 - prediction_days: len(model_inputs) + 7, 0]]
        real_data = np.array(real_data)
        real_data = np.reshape(real_data, (real_data.shape[0], real_data.shape[1], 1))

        prediction = model.predict(real_data)
        prediction = scaler.inverse_transform(prediction)

        actual_price = df['Close'][-1]
        predicted_price = prediction[0][0]

        accuracy_score = r2_score(actual_prices, prediction_prices)

        # Display predicted price and accuracy score
        st.write(f"Future 7th day predicted price using LSTM: {predicted_price:.2f}")
        st.write(f"R-squared Score: {accuracy_score:.2f}")
    except Exception as e:
        st.error("Try later as an error occurred displaying the results. Error message: {}".format(str(e)))

    # Predicting the 30th day using the last 60 days data

    try:
        # Training the data
        start = dt.datetime(2021, 1, 1)
        end = dt.datetime(2022, 1, 1)
        df = yf.download(ticker, start=start, end=end)

        # Prepare data
        scaler = MinMaxScaler(feature_range=(0, 1))
        scaled_data = scaler.fit_transform(df['Close'].values.reshape(-1, 1))

        prediction_days = 60

        future_day = 30

        x_train, y_train = [], []

        for x in range(prediction_days, len(scaled_data) - future_day):
            x_train.append(scaled_data[x - prediction_days:x, 0])
            y_train.append(scaled_data[x + future_day, 0])

        x_train, y_train = np.array(x_train), np.array(y_train)
        x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1], 1))

        # Load my model
        model = load_model('keras7n_model.h5')

        # Testing the model

        test_start = dt.datetime(2022, 1, 2)
        test_end = dt.datetime.now()

        test_data = yf.download(ticker, start=test_start, end=test_end)
        actual_prices = test_data['Close'].values

        total_dataset = pd.concat((df['Close'], test_data['Close']), axis=0)

        model_inputs = total_dataset[len(total_dataset) - len(test_data) - prediction_days:].values
        model_inputs = model_inputs.reshape(-1, 1)
        model_inputs = scaler.fit_transform(model_inputs)

        x_test = []
        for x in range(prediction_days, len(model_inputs)):
            x_test.append(model_inputs[x - prediction_days:x, 0])

        x_test = np.array(x_test)
        x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1))

        prediction_prices = model.predict(x_test)
        prediction_prices = scaler.inverse_transform(prediction_prices)

        fig = plt.figure(figsize=(12, 6))
        plt.title("Future 30th day prediction from last 60 close values")
        plt.plot(actual_prices, color='blue', label='Actual Prices')
        plt.plot(prediction_prices, color='red', label='Predicted Prices')
        plt.xlabel('Time')
        plt.ylabel('Price')
        plt.legend(loc='upper right')
        plt.show()
        st.pyplot(fig)

        # Predict future 30th day's price and accuracy score
        real_data = [model_inputs[len(model_inputs) + 30 - prediction_days: len(model_inputs) + 30, 0]]
        real_data = np.array(real_data)
        real_data = np.reshape(real_data, (real_data.shape[0], real_data.shape[1], 1))

        prediction = model.predict(real_data)
        prediction = scaler.inverse_transform(prediction)

        actual_price = df['Close'][-1]
        predicted_price = prediction[0][0]

        accuracy_score = r2_score(actual_prices, prediction_prices)

        # Display predicted price and accuracy score
        st.write(f"Future 30th day predicted price using LSTM: {predicted_price:.2f}")
        st.write(f"R-squared Score: {accuracy_score:.2f}")
    except Exception as e:
        st.error("Try later as an error occurred displaying the results. Error message: {}".format(str(e)))

    # Predicting the 90th day using the last 60 days data

    try:
        # Train data
        start = dt.datetime(2021, 1, 1)
        end = dt.datetime(2022, 1, 1)
        df = yf.download(ticker, start=start, end=end)

        # Prepare the data
        scaler = MinMaxScaler(feature_range=(0, 1))
        scaled_data = scaler.fit_transform(df['Close'].values.reshape(-1, 1))

        prediction_days = 100

        future_day = 90

        x_train, y_train = [], []

        for x in range(prediction_days, len(scaled_data) - future_day):
            x_train.append(scaled_data[x - prediction_days:x, 0])
            y_train.append(scaled_data[x + future_day, 0])

        x_train, y_train = np.array(x_train), np.array(y_train)
        x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1], 1))

        # Load my model
        model = load_model('keras8n_model.h5')

        # Test data

        test_start = dt.datetime(2022, 1, 2)
        test_end = dt.datetime.now()

        test_data = yf.download(ticker, start=test_start, end=test_end)
        actual_prices = test_data['Close'].values

        total_dataset = pd.concat((df['Close'], test_data['Close']), axis=0)

        model_inputs = total_dataset[len(total_dataset) - len(test_data) - prediction_days:].values
        model_inputs = model_inputs.reshape(-1, 1)
        model_inputs = scaler.fit_transform(model_inputs)

        x_test = []
        for x in range(prediction_days, len(model_inputs)):
            x_test.append(model_inputs[x - prediction_days:x, 0])

        x_test = np.array(x_test)
        x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1))

        prediction_prices = model.predict(x_test)
        prediction_prices = scaler.inverse_transform(prediction_prices)

        fig = plt.figure(figsize=(12, 6))
        plt.title("Future 90th day prediction from last 90 close values")
        plt.plot(actual_prices, color='blue', label='Actual Prices')
        plt.plot(prediction_prices, color='red', label='Predicted Prices')
        plt.xlabel('Time')
        plt.ylabel('Price')
        plt.legend(loc='upper right')
        plt.show()
        st.pyplot(fig)

        # Predict future 90th day's price and accuracy score
        real_data = [model_inputs[len(model_inputs) + 90 - prediction_days: len(model_inputs) + 90, 0]]
        real_data = np.array(real_data)
        real_data = np.reshape(real_data, (real_data.shape[0], real_data.shape[1], 1))

        prediction = model.predict(real_data)
        prediction = scaler.inverse_transform(prediction)

        actual_price = df['Close'][-1]
        predicted_price = prediction[0][0]

        accuracy_score = r2_score(actual_prices, prediction_prices)

        # Display predicted price and accuracy score
        st.write(f"Future 90th day predicted price using LSTM: {predicted_price:.2f}")
        st.write(f"R-squared Score: {accuracy_score:.2f}")
    except Exception as e:
        st.error("Try later as an error occurred displaying the results. Error message: {}".format(str(e)))


# Create an empty dictionary to store session state
session_state = {}


# Re-display sidebar widgets whenever the coin is changed
if session_state.get("prev_ticker") != ticker:
    display_sidebar_widgets(df)
    session_state["prev_ticker"] = ticker


def predict_buy_sell_hold_future(ticker, days_interval, future_days):
    try:
        # Extracting real time data for the cryptocurrency from yahoo finance
        st.markdown("<div style='background-color: #f2f2f2; padding: 10px; border-radius: 5px;'>"
                    "<p style='color:red;'>"
                    "<strong>Next day Decision Prediction</strong>"
                    "</p>"
                    "</div>", unsafe_allow_html=True)

        # st.write("<p style='color:red;'>**Next day Decision Prediction**</p>", unsafe_allow_html=True)
        try:

            ticker = coin_map[coin]

            start = dt.datetime(2022, 1, 1)
            end = dt.datetime.now()
            df = yf.download(ticker, start=start, end=end)

        except ValueError as e:
            st.error(f"Try later as an error occurred while fetching data for {coin}: {str(e)}")
            return

        # Data cleaning. Removing the redundant Adj Close column
        df = df.drop(['Adj Close'], axis='columns')

        # Calculating the moving average for a given number of days
        moving_avg_days = [1, 7, 30, 90]
        for days in moving_avg_days:
            df[f'MA_{days}'] = df['Close'].rolling(window=days).mean()

        # Calculating the percentage change in price for a given number of days
        price_change_days = [1, 7, 30, 90]
        for days in price_change_days:
            df[f'Price_Change_{days}'] = df['Close'].pct_change(periods=days)

        # Filtering the dataframe for the given time interval
        df = df.tail(days_interval + 30)

        # Creating labels for the target variable based on the price change after future days
        df['Target'] = df['Close'].shift(-future_days) >= df['Close']
        df.dropna(inplace=True)

        # Splitting the data into train and test sets
        X = df[
            ['MA_1', 'MA_7', 'MA_30', 'MA_90', 'Price_Change_1', 'Price_Change_7', 'Price_Change_30',
             'Price_Change_90']]
        y = df['Target']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

        # Training the random forest model
        model1 = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=0)
        model2 = RandomForestClassifier(n_estimators=50, max_depth=10, random_state=0)
        model3 = RandomForestClassifier(n_estimators=200, max_depth=3, random_state=0)
        ensemble = VotingClassifier(estimators=[('model1', model1), ('model2', model2), ('model3', model3)],
                                    voting='soft')

        ensemble.fit(X_train, y_train)

        # Predicting the target variable for the test set
        y_pred = ensemble.predict(X_test)


        # Evaluating the accuracy of the model
        accuracy = accuracy_score(y_test, y_pred)

        st.write(f"Random Forest Ensemble Model Accuracy: {accuracy:.2f}")

        # Calculating the training accuracy of the model
        # train_accuracy = ensemble.score(X_train, y_train)
        # st.write(f"Ensemble Model Training Accuracy: {train_accuracy:.2f}")

        # Predictions for future days with dates
        predictions = []
        dates = []
        today = dt.datetime.today().strftime('%Y-%m-%d')
        try:
            for i in range(future_days):
                date = (dt.datetime.today() + dt.timedelta(days=i + 1)).strftime('%Y-%m-%d')
                dates.append(date)
                ma_1, ma_7, ma_30, ma_90 = df.iloc[-1 - i][['MA_1', 'MA_7', 'MA_30', 'MA_90']]
                pct_change_1, pct_change_7, pct_change_30, pct_change_90 = df.iloc[-1 - i][
                    ['Price_Change_1', 'Price_Change_7', 'Price_Change_30', 'Price_Change_90']]
                features = [ma_1, ma_7, ma_30, ma_90, pct_change_1, pct_change_7, pct_change_30, pct_change_90]

                prediction = ensemble.predict([features])[0]
                predictions.append(prediction)

                # Buy, sell, hold signal for each future with dates
                if prediction:
                    signal = "Buy"
                else:
                    signal = "Sell"
                print(f"{date}: {signal}")
        except Exception as e:
            st.write(f"Error occurred while predicting future values: {e}")
            return []

        # Return the predictions for future days
        return predictions
    except ValueError:
        print("ValueError: No decision for now. Please check back later.")
        st.write("ValueError: No decision for now. Please check back later.")
    except Exception as e:
        print(f"Error: {e}")
        st.write(f"Error: {e}")


predictions = predict_buy_sell_hold_future(ticker, days_interval=30,
                                               future_days=1)
if predictions[0]:
    signal = "Buy"
else:
    signal = "Sell"
st.write(f"Prediction Decision for the Next day: {signal}")


def predict_buy_sell_hold_future(ticker, days_interval, future_days):
    try:
        # Extracting real time data for the cryptocurrency from yahoo finance
        st.markdown("<div style='background-color: #f2f2f2; padding: 10px; border-radius: 5px;'>"
                    "<p style='color:red;'>"
                    "<strong>Future 7th day Decision Prediction</strong>"
                    "</p>"
                    "</div>", unsafe_allow_html=True)

        # st.write("<p style='color:red;'>**Future 7th day Decision Prediction**</p>", unsafe_allow_html=True)
        try:

            ticker = coin_map[coin]

            start = dt.datetime(2022, 1, 1)
            end = dt.datetime.now()
            df = yf.download(ticker, start=start, end=end)

        except ValueError as e:
            st.error(f"Try later as an error occurred while fetching data for {coin}: {str(e)}")
            return

        # Data cleaning. Removing the redundant Adj Close column
        df = df.drop(['Adj Close'], axis='columns')

        # Calculating the moving average for a given number of days
        moving_avg_days = [1, 7, 30, 90]
        for days in moving_avg_days:
            df[f'MA_{days}'] = df['Close'].rolling(window=days).mean()

        # Calculating the percentage change in price for a given number of days
        price_change_days = [1, 7, 30, 90]
        for days in price_change_days:
            df[f'Price_Change_{days}'] = df['Close'].pct_change(periods=days)

        # Filtering the dataframe for the given time interval
        df = df.tail(days_interval + 30)

        # Creating labels for the target variable based on the price change after future days
        df['Target'] = df['Close'].shift(-future_days) >= df['Close']
        df.dropna(inplace=True)

        # Splitting the data into train and test sets
        X = df[
            ['MA_1', 'MA_7', 'MA_30', 'MA_90', 'Price_Change_1', 'Price_Change_7', 'Price_Change_30',
             'Price_Change_90']]
        y = df['Target']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

        # Training the random forest model
        model1 = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=0)
        model2 = RandomForestClassifier(n_estimators=50, max_depth=10, random_state=0)
        model3 = RandomForestClassifier(n_estimators=200, max_depth=3, random_state=0)
        ensemble = VotingClassifier(estimators=[('model1', model1), ('model2', model2), ('model3', model3)],
                                    voting='soft')
        ensemble.fit(X_train, y_train)

        # Predicting the target variable for the test set
        y_pred = ensemble.predict(X_test)

        # Evaluating the accuracy of the model
        accuracy = accuracy_score(y_test, y_pred)
        st.write(f"Random Forest Ensemble Model Accuracy: {accuracy:.2f}")

        # Predictions for future days with dates
        predictions = []
        dates = []
        today = dt.datetime.today().strftime('%Y-%m-%d')
        try:
            for i in range(future_days):
                date = (dt.datetime.today() + dt.timedelta(days=i + 1)).strftime('%Y-%m-%d')
                dates.append(date)
                ma_1, ma_7, ma_30, ma_90 = df.iloc[-1 - i][['MA_1', 'MA_7', 'MA_30', 'MA_90']]
                pct_change_1, pct_change_7, pct_change_30, pct_change_90 = df.iloc[-1 - i][
                    ['Price_Change_1', 'Price_Change_7', 'Price_Change_30', 'Price_Change_90']]
                features = [ma_1, ma_7, ma_30, ma_90, pct_change_1, pct_change_7, pct_change_30, pct_change_90]

                prediction = ensemble.predict([features])[0]
                predictions.append(prediction)

                # Buy, sell, hold signal for each future with dates
                if prediction:
                    signal = "Buy"
                else:
                    signal = "Sell"
                print(f"{date}: {signal}")
        except Exception as e:
            st.write(f"Error occurred while predicting future values: {e}")
            return []

        # Return the predictions for future days
        return predictions
    except ValueError:
        print("ValueError: No decision for now. Please check back later.")
        st.write("ValueError: No decision for now. Please check back later.")
    except Exception as e:
        print(f"Error: {e}")
        st.write(f"Error: {e}")


predictions = predict_buy_sell_hold_future(ticker, days_interval=30,
                                               future_days=7)
if predictions[6]:
    signal = "Buy"
else:
    signal = "Sell"
st.write(f"Prediction Decision for the Future 7th day: {signal}")


def predict_buy_sell_hold_future(ticker, days_interval, future_days):
    try:
        # Extracting real time data for the cryptocurrency from yahoo finance
        st.markdown("<div style='background-color: #f2f2f2; padding: 10px; border-radius: 5px;'>"
                    "<p style='color:red;'>"
                    "<strong>Future 30th day Decision Prediction</strong>"
                    "</p>"
                    "</div>", unsafe_allow_html=True)
        # st.write("<p style='color:red;'>**Future 30th day Decision Prediction**</p>", unsafe_allow_html=True)
        try:

            ticker = coin_map[coin]

            start = dt.datetime(2022, 1, 1)
            end = dt.datetime.now()
            df = yf.download(ticker, start=start, end=end)

        except ValueError as e:
            st.error(f"Try later as an error occurred while fetching data for {coin}: {str(e)}")
            return

        # Data cleaning. Removing the redundant Adj Close column
        df = df.drop(['Adj Close'], axis='columns')

        # Calculating the moving average for a given number of days
        moving_avg_days = [1, 7, 30, 90]
        for days in moving_avg_days:
            df[f'MA_{days}'] = df['Close'].rolling(window=days).mean()

        # Calculating the percentage change in price for a given number of days
        price_change_days = [1, 7, 30, 90]
        for days in price_change_days:
            df[f'Price_Change_{days}'] = df['Close'].pct_change(periods=days)

        # Filtering the dataframe for the given time interval
        df = df.tail(days_interval + 90)

        # Creating labels for the target variable based on the price change after future days
        df['Target'] = df['Close'].shift(-future_days) >= df['Close']
        df.dropna(inplace=True)

        # Splitting the data into train and test sets
        X = df[
            ['MA_1', 'MA_7', 'MA_30', 'MA_90', 'Price_Change_1', 'Price_Change_7', 'Price_Change_30',
             'Price_Change_90']]
        y = df['Target']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

        # Training the random forest model
        model1 = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=0)
        model2 = RandomForestClassifier(n_estimators=50, max_depth=10, random_state=0)
        model3 = RandomForestClassifier(n_estimators=200, max_depth=3, random_state=0)
        ensemble = VotingClassifier(estimators=[('model1', model1), ('model2', model2), ('model3', model3)],
                                    voting='soft')
        ensemble.fit(X_train, y_train)

        # Predicting the target variable for the test set
        y_pred = ensemble.predict(X_test)

        # Evaluating the accuracy of the model
        accuracy = accuracy_score(y_test, y_pred)
        st.write(f"Random Forest Ensemble Model Accuracy: {accuracy:.2f}")

        # Predictions for future days with dates
        predictions = []
        dates = []
        today = dt.datetime.today().strftime('%Y-%m-%d')
        try:
            for i in range(future_days):
                date = (dt.datetime.today() + dt.timedelta(days=i + 1)).strftime('%Y-%m-%d')
                dates.append(date)
                ma_1, ma_7, ma_30, ma_90 = df.iloc[-1 - i][['MA_1', 'MA_7', 'MA_30', 'MA_90']]
                pct_change_1, pct_change_7, pct_change_30, pct_change_90 = df.iloc[-1 - i][
                    ['Price_Change_1', 'Price_Change_7', 'Price_Change_30', 'Price_Change_90']]
                features = [ma_1, ma_7, ma_30, ma_90, pct_change_1, pct_change_7, pct_change_30, pct_change_90]

                prediction = ensemble.predict([features])[0]
                predictions.append(prediction)

                # Buy, sell, hold signal for each future with dates
                if prediction:
                    signal = "Buy"
                else:
                    signal = "Sell"
                print(f"{date}: {signal}")
        except Exception as e:
            print(f"Error occurred while predicting future values: {e}")
            st.write(f"Error occurred while predicting future values: {e}")
            return []

    # Return the predictions for future days
        return predictions
    except ValueError:
        print("ValueError: No decision for now. Please check back later.")
        st.write("ValueError: No decision for now. Please check back later.")
    except Exception as e:
        print(f"Error: {e}")
        st.write(f"Error: {e}")


predictions = predict_buy_sell_hold_future(ticker, days_interval=60,
                                               future_days=30)
if predictions[29]:
    signal = "Buy"
else:
    signal = "Sell"
st.write(f"Prediction Decision for the Future 30th day: {signal}")


def predict_buy_sell_hold_future(ticker, days_interval, future_days):
    try:
        # Extracting real time data for the cryptocurrency from yahoo finance
        st.markdown("<div style='background-color: #f2f2f2; padding: 10px; border-radius: 5px;'>"
                    "<p style='color:red;'>"
                    "<strong>Future 90th day Decision Prediction</strong>"
                    "</p>"
                    "</div>", unsafe_allow_html=True)
        # st.write("<p style='color:red;'>**Future 90th day Decision Prediction**</p>", unsafe_allow_html=True)
        try:

            ticker = coin_map[coin]

            start = dt.datetime(2022, 1, 1)
            end = dt.datetime.now()
            df = yf.download(ticker, start=start, end=end)
        except ValueError as e:
            st.error(f"Try later as an error occurred while fetching data for {coin}: {str(e)}")
            return

        # Data cleaning. Removing the redundant Adj Close column
        df = df.drop(['Adj Close'], axis='columns')

        # Calculating the moving average for a given number of days
        moving_avg_days = [1, 7, 30, 90]
        for days in moving_avg_days:
            df[f'MA_{days}'] = df['Close'].rolling(window=days).mean()

        # Calculating the percentage change in price for a given number of days
        price_change_days = [1, 7, 30, 90]
        for days in price_change_days:
            df[f'Price_Change_{days}'] = df['Close'].pct_change(periods=days)

        # Filtering the dataframe for the given time interval
        df = df.tail(days_interval + 100)

        # Creating labels for the target variable based on the price change after future days
        df['Target'] = df['Close'].shift(-future_days) >= df['Close']
        df.dropna(inplace=True)

        # Splitting the data into train and test sets
        X = df[
            ['MA_1', 'MA_7', 'MA_30', 'MA_90', 'Price_Change_1', 'Price_Change_7', 'Price_Change_30',
             'Price_Change_90']]
        y = df['Target']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

        # Training the random forest model
        model1 = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=0)
        model2 = RandomForestClassifier(n_estimators=50, max_depth=10, random_state=0)
        model3 = RandomForestClassifier(n_estimators=200, max_depth=3, random_state=0)
        ensemble = VotingClassifier(estimators=[('model1', model1), ('model2', model2), ('model3', model3)],
                                    voting='soft')
        ensemble.fit(X_train, y_train)

        # Predicting the target variable for the test set
        y_pred = ensemble.predict(X_test)

        # Evaluating the accuracy of the model
        accuracy = accuracy_score(y_test, y_pred)
        st.write(f"Random Forest Ensemble Model Accuracy: {accuracy:.2f}")

        # Predictions for future days with dates
        predictions = []
        dates = []
        today = dt.datetime.today().strftime('%Y-%m-%d')
        try:
            for i in range(future_days):
                date = (dt.datetime.today() + dt.timedelta(days=i + 1)).strftime('%Y-%m-%d')
                dates.append(date)
                ma_1, ma_7, ma_30, ma_90 = df.iloc[-1 - i][['MA_1', 'MA_7', 'MA_30', 'MA_90']]
                pct_change_1, pct_change_7, pct_change_30, pct_change_90 = df.iloc[-1 - i][
                    ['Price_Change_1', 'Price_Change_7', 'Price_Change_30', 'Price_Change_90']]
                features = [ma_1, ma_7, ma_30, ma_90, pct_change_1, pct_change_7, pct_change_30, pct_change_90]

                prediction = ensemble.predict([features])[0]
                predictions.append(prediction)

                # Buy, sell, hold signal for each future with dates
                if prediction:
                    signal = "Buy"
                else:
                    signal = "Sell"
                print(f"{date}: {signal}")
        except Exception as e:
            st.write(f"Error occurred while predicting future values: {e}")
            return []

        # Return the predictions for future days
        return predictions
    except ValueError:
        print("ValueError: No decision for now. Please check back later.")
        st.write("ValueError: No decision for now. Please check back later.")
    except Exception as e:
        print(f"Error: {e}")
        st.write(f"Error: {e}")


predictions = predict_buy_sell_hold_future(ticker, days_interval=60,
                                               future_days=90)
if predictions[89]:
    signal = "Buy"
else:
    signal = "Sell"
st.write(f"Prediction Decision for the Future 90th day: {signal}")


def predict_future_profit_loss(ticker, days_interval, future_days):
    # Extracting real time data for Bitcoin from yahoo finance
    st.markdown("<div style='background-color: #f2f2f2; padding: 10px; border-radius: 5px;'>"
                "<p style='color:red;'>"
                "<strong>Predict Next day profit or loss</strong>"
                "</p>"
                "</div>", unsafe_allow_html=True)

    # st.write("<p style='color:red;'>**Predict Next day profit or loss**</p>", unsafe_allow_html=True)
    try:

        ticker = coin_map[coin]

        start = dt.datetime(2022, 1, 1)
        end = dt.datetime.now()
        df = yf.download(ticker, start=start, end=end)

    except ValueError as e:
        st.error(f"Try later as an error occurred while fetching data for {coin}: {str(e)}")
        return

    # Data cleaning. Removing the redundant Adj Close column
    df = df.drop(['Adj Close'], axis='columns')

    current_price = df['Close'][-1]

    # Calculating the moving average for a given number of days
    moving_avg_days = [1, 7, 30, 90]
    for days in moving_avg_days:
        df[f'MA_{days}'] = df['Close'].rolling(window=days).mean()

    # Calculating the percentage change in price for a given number of days
    price_change_days = [1, 7, 30, 90]
    for days in price_change_days:
        df[f'Price_Change_{days}'] = df['Close'].pct_change(periods=days)

    # Filtering the dataframe for the given time interval
    df = df.tail(days_interval + 90)

    # Creating labels for the target variable based on the price change after future days
    df['Target'] = df['Close'].shift(-future_days)

    # Removing NaN rows
    df.dropna(inplace=True)

    # Scaling the features
    scaler = MinMaxScaler()
    features = ['MA_1', 'MA_7', 'MA_30', 'MA_90', 'Price_Change_1', 'Price_Change_7', 'Price_Change_30',
                'Price_Change_90']
    df[features] = scaler.fit_transform(df[features])

    # Splitting the data into train and test sets
    X = df[features]
    y = df['Target']
    split_index = len(X) - future_days
    X_train, X_test = X[:split_index], X[split_index:]
    y_train, y_test = y[:split_index], y[split_index:]

    # Defining and training the Random Forest Regressor model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    # Predicting the target variable for the test set
    y_pred = model.predict(X_test)

    # Predictions for future
    future_data = df.tail(1)[features]
    future_price = model.predict(future_data)[0]

    # Calculate possible profit/loss for future date
    future_date = dt.datetime.now() + dt.timedelta(days=future_days)
    future_date_str = future_date.strftime('%Y-%m-%d')
    difference = (future_price - current_price)

    percent_change = (difference / current_price) * 100

    if future_price == 0:
        print(
            f"On {future_date_str}, the predicted price is {future_price:.2f}. Predicted price of 0 is not possible.")
    elif percent_change > 0:
        print(
            f"On {future_date_str}, the predicted price is {future_price:.2f}. This is a profit of {percent_change:.2f}% which is {difference:.2f} in USD")
        st.write(
            f"On {future_date_str}, the predicted price using RF Model is {future_price:.2f}. This is a profit of {percent_change:.2f}% which is {difference:.2f} in USD")
    else:
        print(
            f"On {future_date_str}, the predicted price using RF Model is {future_price:.2f}. This is a loss of {percent_change:.2f}% which is {difference:.2f} in USD")
        st.write(
            f"On {future_date_str}, the predicted price using RF Model is {future_price:.2f}. This is a loss of {percent_change:.2f}% which is {difference:.2f} in USD")

        print(f"Current price of {ticker}: {current_price:.2f} USD")
        st.write(f"Current price of {ticker} is {current_price:.2f} USD")

    # Return predict_future_profit_loss
    return future_price, percent_change


future_price, percent_change = predict_future_profit_loss('ticker', 7, 1)


def predict_future_profit_loss(ticker, days_interval, future_days):
    # Extracting real time data for Bitcoin from yahoo finance
    st.markdown("<div style='background-color: #f2f2f2; padding: 10px; border-radius: 5px;'>"
                "<p style='color:red;'>"
                "<strong>Predict Future 7th day profit or loss</strong>"
                "</p>"
                "</div>", unsafe_allow_html=True)

    # st.write("<p style='color:red;'>**Predict Future 7th day profit or loss**</p>", unsafe_allow_html=True)
    try:

        ticker = coin_map[coin]

        start = dt.datetime(2022, 1, 1)
        end = dt.datetime.now()
        df = yf.download(ticker, start=start, end=end)

    except ValueError as e:
        st.error(f"Try later as an error occurred while fetching data for {coin}: {str(e)}")
        return

    # Data cleaning. Removing the redundant Adj Close column
    df = df.drop(['Adj Close'], axis='columns')

    current_price = df['Close'][-1]

    # Calculating the moving average for a given number of days
    moving_avg_days = [1, 7, 30, 90]
    for days in moving_avg_days:
        df[f'MA_{days}'] = df['Close'].rolling(window=days).mean()

    # Calculating the percentage change in price for a given number of days
    price_change_days = [1, 7, 30, 90]
    for days in price_change_days:
        df[f'Price_Change_{days}'] = df['Close'].pct_change(periods=days)

    # Filtering the dataframe for the given time interval
    df = df.tail(days_interval + 90)

    # Creating labels for the target variable based on the price change after future days
    df['Target'] = df['Close'].shift(-future_days)

    # Removing NaN rows
    df.dropna(inplace=True)

    # Scaling the features
    scaler = MinMaxScaler()
    features = ['MA_1', 'MA_7', 'MA_30', 'MA_90', 'Price_Change_1', 'Price_Change_7', 'Price_Change_30',
                'Price_Change_90']
    df[features] = scaler.fit_transform(df[features])

    # Splitting the data into train and test sets
    X = df[features]
    y = df['Target']

    split_index = len(X) - future_days
    X_train, X_test = X[:split_index], X[split_index:]
    y_train, y_test = y[:split_index], y[split_index:]

    # Defining and training the Random Forest Regressor model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    # Predicting the target variable for the test set
    y_pred = model.predict(X_test)

    # Predictions for future
    future_data = df.tail(1)[features]
    future_price = model.predict(future_data)[0]

    # Calculate possible profit/loss for future date
    future_date = dt.datetime.now() + dt.timedelta(days=future_days)
    future_date_str = future_date.strftime('%Y-%m-%d')
    difference = (future_price - current_price)

    percent_change = (difference / current_price) * 100

    if future_price == 0:
        print(
            f"On {future_date_str}, the predicted price is {future_price:.2f}. Predicted price of 0 is not possible.")
    elif percent_change > 0:
        print(
            f"On {future_date_str}, the predicted price is {future_price:.2f}. This is a profit of {percent_change:.2f}% which is {difference:.2f} in USD")
        st.write(
            f"On {future_date_str}, the predicted price using RF Model is {future_price:.2f}. This is a profit of {percent_change:.2f}% which is {difference:.2f} in USD")
    else:
        print(
            f"On {future_date_str}, the predicted price using RF Model is {future_price:.2f}. This is a loss of {percent_change:.2f}% which is {difference:.2f} in USD")
        st.write(
            f"On {future_date_str}, the predicted price using RF Model is {future_price:.2f}. This is a loss of {percent_change:.2f}% which is {difference:.2f} in USD")

        print(f"Current price of {ticker}: {current_price:.2f} USD")
        st.write(f"Current price of {ticker} is {current_price:.2f} USD")


    # Return predict_future_profit_loss
    return future_price, percent_change


future_price, percent_change = predict_future_profit_loss('ticker', 30, 7)




def predict_future_profit_loss(ticker, days_interval, future_days):
    # Extracting real time data for Bitcoin from yahoo finance
    st.markdown("<div style='background-color: #f2f2f2; padding: 10px; border-radius: 5px;'>"
                "<p style='color:red;'>"
                "<strong>Predict Future 30th day profit or loss</strong>"
                "</p>"
                "</div>", unsafe_allow_html=True)

    # st.write("<p style='color:red;'>**Predict Future 30th day profit or loss**</p>", unsafe_allow_html=True)
    try:

        ticker = coin_map[coin]

        start = dt.datetime(2022, 1, 1)
        end = dt.datetime.now()
        df = yf.download(ticker, start=start, end=end)
    except ValueError as e:
        st.error(f"Try later as an error occurred while fetching data for {coin}: {str(e)}")
        return

    # Data cleaning. Removing the redundant Adj Close column
    df = df.drop(['Adj Close'], axis='columns')

    current_price = df['Close'][-1]

    # Calculating the moving average for a given number of days
    moving_avg_days = [1, 7, 30, 90]
    for days in moving_avg_days:
        df[f'MA_{days}'] = df['Close'].rolling(window=days).mean()

    # Calculating the percentage change in price for a given number of days
    price_change_days = [1, 7, 30, 90]
    for days in price_change_days:
        df[f'Price_Change_{days}'] = df['Close'].pct_change(periods=days)

    # Filtering the dataframe for the given time interval
    df = df.tail(days_interval + 90)

    # Creating labels for the target variable based on the price change after future days
    df['Target'] = df['Close'].shift(-future_days)

    # Removing NaN rows
    df.dropna(inplace=True)

    # Scaling the features
    scaler = MinMaxScaler()
    features = ['MA_1', 'MA_7', 'MA_30', 'MA_90', 'Price_Change_1', 'Price_Change_7', 'Price_Change_30',
                'Price_Change_90']
    df[features] = scaler.fit_transform(df[features])

    # Splitting the data into train and test sets
    X = df[features]
    y = df['Target']
    split_index = len(X) - future_days
    X_train, X_test = X[:split_index], X[split_index:]
    y_train, y_test = y[:split_index], y[split_index:]

    # Defining and training the Random Forest Regressor model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    # Predicting the target variable for the test set
    y_pred = model.predict(X_test)

    # Predictions for future
    future_data = df.tail(1)[features]
    future_price = model.predict(future_data)[0]

    # Calculate possible profit/loss for future date
    future_date = dt.datetime.now() + dt.timedelta(days=future_days)
    future_date_str = future_date.strftime('%Y-%m-%d')
    difference = (future_price - current_price)

    percent_change = (difference / current_price) * 100

    if future_price == 0:
        print(
            f"On {future_date_str}, the predicted price is {future_price:.2f}. Predicted price of 0 is not possible.")
    elif percent_change > 0:
        print(
            f"On {future_date_str}, the predicted price is {future_price:.2f}. This is a profit of {percent_change:.2f}% which is {difference:.2f} in USD")
        st.write(
            f"On {future_date_str}, the predicted price using RF Model is {future_price:.2f}. This is a profit of {percent_change:.2f}% which is {difference:.2f} in USD")
    else:
        print(
            f"On {future_date_str}, the predicted price using RF Model is {future_price:.2f}. This is a loss of {percent_change:.2f}% which is {difference:.2f} in USD")
        st.write(
            f"On {future_date_str}, the predicted price using RF Model is {future_price:.2f}. This is a loss of {percent_change:.2f}% which is {difference:.2f} in USD")

        print(f"Current price of {ticker}: {current_price:.2f} USD")
        st.write(f"Current price of {ticker} is {current_price:.2f} USD")

    # Return predict_future_profit_loss
    return future_price, percent_change


future_price, percent_change = predict_future_profit_loss('ticker', 30, 30)


def predict_future_profit_loss(ticker, days_interval, future_days):
    # Extracting real time data for Bitcoin from yahoo finance
    st.markdown("<div style='background-color: #f2f2f2; padding: 10px; border-radius: 5px;'>"
                "<p style='color:red;'>"
                "<strong>Predict Future 90th day profit or loss</strong>"
                "</p>"
                "</div>", unsafe_allow_html=True)
    try:

        ticker = coin_map[coin]

        start = dt.datetime(2022, 1, 1)
        end = dt.datetime.now()
        df = yf.download(ticker, start=start, end=end)
        # Data cleaning. Removing the redundant Adj Close column
        df = df.drop(['Adj Close'], axis='columns')

    except ValueError as e:
        st.error(f"Try later as an error occurred while fetching data for {coin}: {str(e)}")
        return

    current_price = df['Close'][-1]

    # Calculating the moving average for a given number of days
    moving_avg_days = [1, 7, 30, 90]
    for days in moving_avg_days:
        df[f'MA_{days}'] = df['Close'].rolling(window=days).mean()

    # Calculating the percentage change in price for a given number of days
    price_change_days = [1, 7, 30, 90]
    for days in price_change_days:
        df[f'Price_Change_{days}'] = df['Close'].pct_change(periods=days)

    # Filtering the dataframe for the given time interval
    df = df.tail(days_interval + 90)

    # Creating labels for the target variable based on the price change after future days
    df['Target'] = df['Close'].shift(-future_days)

    # Removing NaN rows
    df.dropna(inplace=True)

    # Scaling the features
    scaler = MinMaxScaler()
    features = ['MA_1', 'MA_7', 'MA_30', 'MA_90', 'Price_Change_1', 'Price_Change_7', 'Price_Change_30',
                'Price_Change_90']
    df[features] = scaler.fit_transform(df[features])

    # Splitting the data into train and test sets
    X = df[features]
    y = df['Target']
    split_index = len(X) - future_days
    X_train, X_test = X[:split_index], X[split_index:]
    y_train, y_test = y[:split_index], y[split_index:]

    # Defining and training the Random Forest Regressor model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    # Predicting the target variable for the test set
    y_pred = model.predict(X_test)

    # Predictions for future
    future_data = df.tail(1)[features]
    future_price = model.predict(future_data)[0]

    # Calculate possible profit/loss for future date
    future_date = dt.datetime.now() + dt.timedelta(days=future_days)
    future_date_str = future_date.strftime('%Y-%m-%d')
    difference = (future_price - current_price)

    percent_change = (difference / current_price) * 100

    if future_price == 0:
        print(f"On {future_date_str}, the predicted price is {future_price:.2f}. Predicted price of 0 is not possible.")
    elif percent_change > 0:
        print(
            f"On {future_date_str}, the predicted price is {future_price:.2f}. This is a profit of {percent_change:.2f}% which is {difference:.2f} in USD")
        st.write(f"On {future_date_str}, the predicted price using RF Model is {future_price:.2f}. This is a profit of {percent_change:.2f}% which is {difference:.2f} in USD")
    else:
        print(f"On {future_date_str}, the predicted price using RF Model is {future_price:.2f}. This is a loss of {percent_change:.2f}% which is {difference:.2f} in USD")
        st.write(f"On {future_date_str}, the predicted price using RF Model is {future_price:.2f}. This is a loss of {percent_change:.2f}% which is {difference:.2f} in USD")

        print(f"Current price of {ticker}: {current_price:.2f} USD")
        st.write(f"Current price of {ticker} is {current_price:.2f} USD")

    # Return predict_future_profit_loss
    return future_price, percent_change


future_price, percent_change = predict_future_profit_loss('ticker', 50, 90)


def draw_heatmap(coin, correlation_cutoff):
    st.markdown("<div style='background-color: #f2f2f2; padding: 10px; border-radius: 5px;'>"
                "<p style='color:red;'>"
                "<strong>Heat map of high positive correlation with other coins </strong>"
                "</p>"
                "</div>", unsafe_allow_html=True)

    ticker = coin_map.get(coin)
    if not ticker:
        st.error("Selected coin is currently not available. Please select another coin.")
        return
    try:
        start = pd.to_datetime("2022-01-01")
        end = pd.to_datetime("now")
        df = yf.download(ticker, start=start, end=end).loc[:, 'Close']
        df.name = ticker  # set the name of the Series object to the ticker
    except Exception as e:
        st.error(f"Try later as an error occurred while trying to download data for {ticker}: {e}")
        return

    # Create a list of coins to consider, which includes the selected coin
    coins_of_interest = list(coin_map.values())

    # Get the correlation matrix for the coins of interest
    corr = pd.DataFrame({coin: df})
    for coin in coins_of_interest:
        temp_df = yf.download(coin, start=start, end=end).loc[:, 'Close']
        temp_df.name = coin
        corr[coin] = temp_df

    # Calculate correlation using only the Close column
    corr = corr.corr()

    # Filter correlation coefficients >= correlation_cutoff
    corr_cutoff = corr[(corr >= correlation_cutoff) & (corr < 1)]

    # Check if corr_cutoff is empty
    if corr_cutoff.empty:
        st.write(f"No coins highly correlated with {coin}.")
        return

    # Get the top 10 correlated coins
    top_coins = corr_cutoff[coin].sort_values(ascending=False).head(10).index

    # Add coin to the list of top coins
    top_coins = top_coins.append(pd.Index([ticker]))

    # Filter the correlation matrix for the top correlated coins
    corr = corr.loc[top_coins, top_coins]

    # Create heatmap
    fig, ax = plt.subplots(figsize=(12, 10))
    sns.heatmap(corr, annot=True, cmap="coolwarm", square=True, ax=ax)
    ax.set_title(f"Correlation Heatmap for {df.name} with 10 highly correlated coins")
    st.pyplot(fig)


# Call the draw_heatmap function with the selected coin when a user selects a coin
draw_heatmap(coin, correlation_cutoff=0.7)




